import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {Pokemon chosenPokemon = new Pikachu();
       Pokemon enemyPokemon1 = new EnemyPokemon1();
       chosenPokemon.enemyPokemon = enemyPokemon1;
       chosenPokemon.chooseAttack();
       //THE SOLUTION IS TO JUST MOVE THE round1(), round2(), quarterFinals(), semifinals(), TheFinalBattle() an prize(), in main.
    }
}