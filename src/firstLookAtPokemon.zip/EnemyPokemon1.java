public class EnemyPokemon1 extends Pokemon{
    EnemyPokemon1() {
        this.name = "Eevee";
        this.appearance = "mammalian creature with brown fur, a bushy tail that has a cream-colored tip, and a furry collar that is also cream-colored.";
        this.type = "Ordinary";
        this.size = "Small";
        this.setHealthPoints(55);
        this.setAttackPoints(55);
        this.setDefensePoints(50);
    }
    @Override
    void strengthModifier() {
        this.setHealthPoints(this.getHealthPoints() - (this.getHealthPoints() / 10));
        this.setAttackPoints(this.getAttackPoints() - (this.getAttackPoints() / 10));
        this.setDefensePoints((this.getDefensePoints() - (this.getDefensePoints() / 10)));
    }

    @Override
    void chooseAttack() {

    }
    void attack1(){
        chosenPokemon.setHealthPoints(chosenPokemon.getHealthPoints() - 20);
    }
}
