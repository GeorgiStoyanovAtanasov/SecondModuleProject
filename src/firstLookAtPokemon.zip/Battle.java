import java.util.ArrayList;

public class Battle {

    public void round2() {

    }

    public void quarterFinals() {

    }

    public void semifinals() {

    }

    public void TheFinalBattle() {

    }

    public void prize() {

    }
}
