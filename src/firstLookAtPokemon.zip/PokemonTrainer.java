public class PokemonTrainer {
}
